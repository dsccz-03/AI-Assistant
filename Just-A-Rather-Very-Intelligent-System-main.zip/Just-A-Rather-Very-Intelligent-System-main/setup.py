import subprocess

subprocess.run("pip install -r requirements.txt")