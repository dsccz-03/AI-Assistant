import pywhatkit as pw

def play_music_on_youtube(Song_name):
    pw.playonyt(Song_name)
